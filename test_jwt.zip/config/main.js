module.exports = {
    'secret': "Passphrase for encryption",
    'database_host': 'localhost',
    'database_user': 'root',
    'database_password': '',
    'database_name': 'test_jwt'
}